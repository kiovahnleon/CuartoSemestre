function App() {

  return (
    <div className="text-white mx-14 uppercase font-Tapestry md:text-emerald-500 ">
      <h1 className="text-[40px] p-10 bg-orange-400 mt-5 text-center mx-auto ">Aprendiendo React</h1>
    </div>
  )
}

export default App
