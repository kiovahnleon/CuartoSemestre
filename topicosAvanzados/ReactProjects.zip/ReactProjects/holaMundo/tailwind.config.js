module.exports = {
  content: ["index.html","./src/**/*.{html,jsx}"],
  theme: {
    fontFamily:{
      Tapestry:'Tapestry'
    },
    extend: {},
  },
  plugins: [],
}
