module.exports = {
  content: ["index.html","./src/**/*.jsx"],
  theme: {
    extend: {},
  },
  plugins: [],
}