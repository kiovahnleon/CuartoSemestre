import React from 'react'

const Listado = () => {
    return (
        <div className='bg-orange-300 mr-10 text-center rounded-md p-4'>Listado</div>
    )
}

export default Listado